package bean.comm;

public class Commodify {
	public Commodify(){
		
	}
	private String commaddid;
	private String commaddname;
	private String commprice;
	private String commurl;
	public String getCommaddid() {
		return commaddid;
	}
	public void setCommaddid(String commaddid) {
		this.commaddid = commaddid;
	}
	public String getCommaddname() {
		return commaddname;
	}
	public void setCommaddname(String commaddname) {
		this.commaddname = commaddname;
	}
	public String getCommprice() {
		return commprice;
	}
	public void setCommprice(String commprice) {
		this.commprice = commprice;
	}
	public String getCommurl() {
		return commurl;
	}
	public void setCommurl(String commurl) {
		this.commurl = commurl;
	}
	
}
